// engine.js — core analysis pipeline: parse -> segment -> speaker split -> analyze -> score.
// Zero dependencies. Runs in browser (global ConvMap.Engine) and Node (require).
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory(require('./lexicon.js'));
  else { root.ConvMap = root.ConvMap || {}; root.ConvMap.Engine = factory(root.ConvMap.Lexicon); }
}(typeof self !== 'undefined' ? self : this, function (L) {
  'use strict';

  /* ---------- small utils ---------- */
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  function round2(v) { return Math.round(v * 100) / 100; }

  function toSeconds(ts) {
    if (ts == null) return null;
    if (typeof ts === 'number') return ts;
    var s = String(ts).trim();
    var m = s.match(/^(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)$/);
    if (m) return (+(m[1] || 0)) * 3600 + (+m[2]) * 60 + (+m[3]);
    var sec = parseFloat(s.replace(/s$/i, ''));
    return isNaN(sec) ? null : sec;
  }
  function fmtTs(sec) {
    if (sec == null || isNaN(sec)) return '';
    sec = Math.max(0, Math.round(sec));
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    return (h > 0 ? (h < 10 ? '0' : '') + h + ':' : '') + (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }
  function snippet(text, n) {
    n = n || 70;
    var t = text.replace(/\s+/g, ' ').trim();
    return t.length > n ? t.slice(0, n).replace(/\s+\S*$/, '') + '…' : t;
  }
  function cleanSpeaker(name) {
    return String(name).trim().replace(/\s+/g, ' ').replace(/^(speaker|user)\s*[:.\-]?/i, 'Speaker ');
  }

  /* ---------- 1. parse transcript (dialog lines or JSON) ---------- */
  function parseTranscript(text) {
    if (!text || !text.trim()) return { utterances: [], format: 'none' };
    var trimmed = text.trim();
    var utterances = [];

    // JSON input: {"segments":[...]} / {"utterances":[...]} / plain array
    if (trimmed[0] === '{' || trimmed[0] === '[') {
      try {
        var obj = JSON.parse(trimmed);
        var segs = obj.segments || obj.utterances || (Array.isArray(obj) ? obj : null);
        if (segs && segs.length) {
          segs.forEach(function (seg, i) {
            var txt = seg.text || seg.content || '';
            if (!txt) return;
            utterances.push({
              idx: utterances.length, raw: txt,
              time: toSeconds(seg.start != null ? seg.start : (seg.timestamp != null ? seg.timestamp : seg.time)),
              speaker: cleanSpeaker(seg.speaker || seg.speaker_name || ('Speaker ' + ((i % 2) + 1))),
              source: 'json'
            });
          });
          fillTimes(utterances);
          return { utterances: utterances, format: 'json' };
        }
      } catch (e) { /* fall through to dialog parse */ }
    }

    // Dialog lines: "[00:04:12] Name: text" or "Name: text"
    var lines = trimmed.split(/\r?\n/);
    var distinct = [];
    lines.forEach(function (line) {
      line = line.trim();
      if (!line) return;
      var m = line.match(/^\s*(?:\[([^\]]+)\]\s*)?([^:]{1,40}?)\s*:\s?(.*)$/);
      if (m && m[3]) {
        var sp = cleanSpeaker(m[2]);
        if (distinct.indexOf(sp) < 0) distinct.push(sp);
        utterances.push({ idx: utterances.length, raw: m[3], time: toSeconds(m[1]), speaker: sp, source: 'dialog' });
        return;
      }
      // no speaker prefix
      var prev = utterances[utterances.length - 1];
      if (prev && /^[\p{Ll}(,\s]/.test(line) && line.length < 200) {
        prev.raw += ' ' + line; // continuation of the previous turn
        return;
      }
      // otherwise treat as a new turn from the OTHER speaker (alternating)
      var other = distinct.filter(function (s) { return s !== (prev ? prev.speaker : null); })[0];
      if (!other) other = distinct[0] || 'Speaker 2';
      if (distinct.indexOf(other) < 0) distinct.push(other);
      utterances.push({ idx: utterances.length, raw: line, time: null, speaker: other, source: 'dialog' });
    });
    fillTimes(utterances);
    return { utterances: utterances, format: 'dialog' };
  }

  function fillTimes(utterances) {
    var t = 0;
    utterances.forEach(function (u) {
      if (u.time == null) u.time = t;
      else t = u.time;
      t += Math.max(3, Math.min(30, Math.round(u.raw.length / 12))); // estimated turn length
    });
  }

  /* ---------- 2. score one utterance ---------- */
  function analyzeUtterance(u, ctx) {
    var text = u.raw, lower = text.toLowerCase();
    var words = lower.match(/[a-z']+/g) || [];

    var posHits = [], negHits = [], toxHits = [], boosters = [];
    words.forEach(function (w, i) {
      var negated = false;
      for (var b = Math.max(0, i - 3); b < i; b++) {
        if (/^(not|n't|never|no|don't|doesn't|didn't|won't|can't|cannot|isn't|aren't|without)$/.test(words[b])) { negated = true; break; }
      }
      if (L.POSITIVE.indexOf(w) >= 0) posHits.push(negated ? '!' + w : w);
      if (L.NEGATIVE.indexOf(w) >= 0) negHits.push(negated ? '!' + w : w);
      if (L.TOXIC.indexOf(w) >= 0) toxHits.push(w);
      if (L.INTENSIFIERS.indexOf(w) >= 0) boosters.push(w);
    });
    L.TOXIC.forEach(function (t) {
      if (t.indexOf(' ') > 0 && lower.indexOf(t) >= 0 && toxHits.indexOf(t) < 0) toxHits.push(t);
    });

    var hasShout = /[A-Z]{2,}/.test(text) || /!{1,}/.test(text);
    var intensBoost = 1 + Math.min(2, boosters.length) * 0.35;

    var posCount = posHits.filter(function (w) { return w[0] !== '!'; }).length;
    var negCount = negHits.filter(function (w) { return w[0] !== '!'; }).length;
    var sentimentScore = posCount - negCount * 1.15;

    /* patterns */
    var patterns = [];
    function matchList(list) {
      list.forEach(function (p) { if (p.re.test(text) && patterns.indexOf(p.label) < 0) patterns.push(p.label); });
    }
    matchList(L.GENERALIZATION_RE); matchList(L.ABSOLUTE_RE); matchList(L.BLAME_RE);
    matchList(L.DEFENSIVE_RE); matchList(L.CONCESSION_RE); matchList(L.REQUEST_RE); matchList(L.APOLOGY_RE);

    var negativePattern = /(Generalization|Absolute|Personal blame|Personal attack|Blame attribution|Defensiveness)/.test(patterns.join(' '));
    var deescalating = /(Concession|Agreement|Apology|Willingness|De-escalation attempt|Compromise attempt)/.test(patterns.join(' '));

    /* sentiment */
    var sentiment;
    if (sentimentScore > 0.5) sentiment = 'positive';
    else if (sentimentScore < -0.15) sentiment = 'negative';
    else sentiment = 'neutral';
    // soften: an apology/concession turn is not a hostile red point
    if (deescalating && toxHits.length === 0 && !negativePattern) {
      sentiment = sentimentScore >= 0.5 ? 'positive' : 'neutral';
    }

    /* emotional intensity 0..1 */
    var intensity = clamp(
      negCount * 0.2 + toxHits.length * 0.22 + boosters.length * 0.1 + (hasShout ? 0.2 : 0) + (negativePattern ? 0.12 : 0),
      0, 1);

    /* topic: best-scoring topic */
    var topic = 'General', bestScore = 0;
    L.TOPICS.forEach(function (t) {
      var score = lower.match(new RegExp(t.re.source, 'gi')) ? (lower.match(new RegExp(t.re.source, 'gi')) || []).length : 0;
      score += (t.re.test(text) ? 1 : 0);
      if (score > bestScore) { bestScore = score; topic = t.name; }
    });

    /* conflict dynamics */
    var delta = 0;
    if (sentiment === 'negative') delta += 0.12 + intensity * 0.22;
    if (negativePattern) delta += 0.18;
    if (toxHits.length) delta += 0.22;
    if (deescalating) delta -= 0.4;
    else if (sentiment === 'positive') delta -= 0.12;

    var before = ctx.conflict;
    ctx.conflict = clamp(ctx.conflict + delta, 0, 1);

    var trigger = null;
    if (sentiment === 'negative' && (patterns.length || toxHits.length)) {
      trigger = {
        reason: toxHits.length ? 'toxic or insulting wording (“' + toxHits[0] + '”)'
          : ('a ' + patterns[0].toLowerCase() + ' pattern'),
        pattern: patterns[0] || null,
        topic: topic
      };
    }

    var result = {
      timestamp: fmtTs(u.time),
      time: u.time,
      speaker: u.speaker,
      text: u.raw,
      topic: topic,
      tone: toneFor(sentiment, intensity, patterns, toxHits, deescalating),
      sentiment: sentiment,
      emotional_intensity: round2(intensity),
      negative_words: negHits,
      positive_words: posHits,
      toxic_words: toxHits,
      patterns: patterns,
      communication_pattern: patterns[0] || null,
      possible_trigger: trigger,
      conflict_delta: round2(delta),
      conflict_after: round2(ctx.conflict),
      conflict_level: levelFor(ctx.conflict),
      deescalating: deescalating,
      idx: u.idx
    };
    ctx.results.push(result);
    return result;
  }

  function toneFor(sentiment, intensity, patterns, toxHits, deescalating) {
    if (toxHits.length) return 'hostile';
    if (patterns.indexOf('Defensiveness') >= 0) return 'defensive';
    if (deescalating) return 'conciliatory';
    if (sentiment === 'negative' && intensity > 0.45) return 'frustrated';
    if (sentiment === 'negative') return 'negative';
    if (sentiment === 'positive') return 'positive';
    return 'neutral';
  }

  function levelFor(v) {
    if (v < 0.34) return 'low';
    if (v < 0.6) return 'rising';
    if (v < 0.85) return 'high';
    return 'critical';
  }

  /* ---------- 3. run whole analysis ---------- */
  function analyzeAll(utterances) {
    var ctx = { conflict: 0.12, results: [] };
    utterances.forEach(function (u) { analyzeUtterance(u, ctx); });
    var results = ctx.results;

    var escalations = [], deescalations = [];
    results.forEach(function (r) {
      if (r.conflict_delta > 0.3) {
        escalations.push({
          time: r.time, timecode: r.timestamp, speaker: r.speaker, idx: r.idx,
          from: round2(r.conflict_after - r.conflict_delta), to: r.conflict_after,
          cause: r.toxic_words.length ? 'toxic wording' : (r.patterns[0] || r.sentiment + ' turn')
        });
      }
      if (r.conflict_delta < -0.25) {
        deescalations.push({
          time: r.time, timecode: r.timestamp, speaker: r.speaker, idx: r.idx,
          cause: r.patterns[0] || 'calming turn'
        });
      }
    });

    var speakers = [];
    results.forEach(function (r) { if (speakers.indexOf(r.speaker) < 0) speakers.push(r.speaker); });
    return { utterances: results, escalations: escalations, deescalations: deescalations, speakers: speakers };
  }

  /* ---------- 4. summary with hedged wording + rephrasings ---------- */
  var REPHRASINGS = {
    'Generalization': {
      suggestion: 'Replace always/never with one specific instance — specifics are harder to argue with than absolutes.',
      example: '“You never help” → “I felt unsupported when the task was left unfinished.”'
    },
    'Absolute language': {
      suggestion: 'Consider reviewing how often something actually happens — frequency data cools the argument.',
      example: '“You always …” → “This has happened a few times this week.”'
    },
    'Personal blame': {
      suggestion: 'Shift from person to issue: describe the situation and its impact.',
      example: '“You’re the problem” → “The disagreement seems connected to unclear responsibilities.”'
    },
    'Personal attack': {
      suggestion: 'Talk about the specific behavior, not the person.',
      example: '“You’re selfish” → “When the report went out late, it added work for the team.”'
    },
    'Blame attribution': {
      suggestion: 'Ask “what contributed?” instead of “whose fault?”.',
      example: '“It’s your fault” → “What made the deadline slip, and what can we change?”'
    },
    'Defensiveness': {
      suggestion: 'Acknowledge the other person’s perspective before sharing yours.',
      example: '“That’s not true” → “I can see why it looked that way. Here’s what I saw.”'
    }
  };

  function buildSummary(uris) {
    var speakers = {}, topics = {}, patterns = {};
    uris.forEach(function (u) {
      speakers[u.speaker] = (speakers[u.speaker] || 0) + 1;
      topics[u.topic] = (topics[u.topic] || 0) + 1;
      u.patterns.forEach(function (p) { patterns[p] = (patterns[p] || 0) + 1; });
    });

    var peak = null;
    uris.forEach(function (u) { if (!peak || u.conflict_after > peak.conflict_after) peak = u; });
    var trig = uris.filter(function (u) { return u.possible_trigger; });
    var de = uris.filter(function (u) { return u.deescalating; });
    var firstNeg = uris.filter(function (u) { return u.sentiment === 'negative'; })[0] || null;

    var topPatterns = Object.keys(patterns).sort(function (a, b) { return patterns[b] - patterns[a]; });

    var lines = [];
    lines.push('Analyzed ' + uris.length + ' turns · ' + Object.keys(speakers).join(', ') + ' · topics: ' + Object.keys(topics).join(' / '));
    if (topPatterns.length) {
      lines.push('Detected pattern' + (topPatterns.length > 1 ? 's' : '') + ': ' + topPatterns.slice(0, 3).join(', ') + ' — may indicate recurring communication habits worth reviewing.');
    } else {
      lines.push('No strong linguistic patterns detected in this sample.');
    }
    if (peak && peak.conflict_after > 0.4) {
      lines.push('Conflict appeared to peak at ' + peak.timestamp + ' (' + peak.conflict_level + '), around the topic “' + peak.topic + '”.');
    }
    if (trig.length) {
      var t0 = trig[0];
      lines.push('A possible trigger appears around “' + t0.topic + '” at ' + t0.timestamp + ': “' + snippet(t0.text) + '” — likely related to ' + t0.possible_trigger.reason + '. This interpretation is uncertain.');
    }
    if (de.length) {
      lines.push(de.length + ' de-escalation attempt' + (de.length > 1 ? 's' : '') + ' detected (concession / apology / agreement), starting at ' + de[0].timestamp + '.');
    }
    if (firstNeg && peak && peak.conflict_after > 0.4) {
      lines.push('Consider reviewing the section from ' + firstNeg.timestamp + ' to ' + peak.timestamp + ' with the rephrasing suggestions below.');
    }
    lines.push('Note: emotion and intent cannot be determined perfectly from speech alone — every label here is probabilistic, not a verdict.');

    var rephrasings = [], seen = {};
    uris.forEach(function (u) {
      u.patterns.forEach(function (p) {
        if (!seen[p] && REPHRASINGS[p]) {
          seen[p] = 1;
          rephrasings.push({ pattern: p, suggestion: REPHRASINGS[p].suggestion, example: REPHRASINGS[p].example, from_text: u.text });
        }
      });
    });
    if (!rephrasings.length) {
      rephrasings.push({ pattern: 'General', suggestion: 'No pattern-specific suggestion — consider reviewing the conversation with the speakers directly.', example: '', from_text: '' });
    }

    return {
      turns: uris.length, speakers: speakers, topics: topics, patterns: patterns,
      peak: peak, summaryLines: lines, rephrasings: rephrasings,
      overall_level: peak ? peak.conflict_level : 'low'
    };
  }

  /* ---------- 5. mind-map data ---------- */
  function buildMindMapData(uris) {
    var topics = [], map = {};
    uris.forEach(function (u) {
      if (!map[u.topic]) { map[u.topic] = { label: u.topic, children: [] }; topics.push(map[u.topic]); }
      map[u.topic].children.push(u);
    });
    return {
      topics: topics,
      triggers: uris.filter(function (u) { return u.possible_trigger; }),
      resolutions: uris.filter(function (u) { return u.deescalating; })
    };
  }

  return {
    parseTranscript: parseTranscript,
    analyzeAll: analyzeAll,
    analyzeUtterance: analyzeUtterance,
    buildSummary: buildSummary,
    buildMindMapData: buildMindMapData,
    levelFor: levelFor,
    fmtTs: fmtTs
  };
}));
