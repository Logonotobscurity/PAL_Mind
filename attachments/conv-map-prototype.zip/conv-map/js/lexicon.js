// lexicon.js — word lists + pattern rules for the rule engine.
// Zero dependencies. Loaded in browser as a classic script, or in Node via require.
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else { root.ConvMap = root.ConvMap || {}; root.ConvMap.Lexicon = factory(); }
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var POSITIVE = [
    'agree', 'agreed', 'appreciate', 'appreciated', 'good', 'great', 'happy', 'thank', 'thanks',
    'thankful', 'helpful', 'understand', 'understood', 'okay', 'ok', 'fine', 'love', 'like',
    'nice', 'best', 'better', 'clear', 'clearly', 'solution', 'resolve', 'resolved', 'fair',
    'works', 'working', 'support', 'trust', 'glad', 'yes', 'sure', 'perfect', 'awesome',
    'calm', 'hopeful', 'willing', 'let', 'lets', 'together', 'tomorrow', 'great'
  ];

  var NEGATIVE = [
    'never', 'always', 'hate', 'bad', 'worst', 'wrong', 'failure', 'failed', 'fail', 'impossible',
    'stupid', 'useless', 'waste', 'wasted', 'ignore', 'ignored', 'interrupt', 'blame', 'blamed',
    'fault', 'problem', 'unfair', 'late', 'missed', 'forgot', "can't", 'cannot', "won't",
    'nothing', 'nobody', 'terrible', 'awful', 'angry', 'frustrated', 'frustrating', 'annoying',
    'annoyed', 'upset', 'sick', 'tired', 'lying', 'lie', 'liar', 'selfish', 'lazy', 'crazy',
    'unprofessional', 'disappointed', 'disappointing', 'pointless', 'ridiculous', 'unacceptable',
    'impossible', 'impossible', 'hard', 'difficult', 'stressful', 'stressed', 'furious', 'mad',
    'irritating', 'irritated', 'fed', 'defensive', 'blames', 'ignores', 'ignoring', 'sarcastic', 'broken', 'ruined', 'mess', 'chaos', 'chaotic'
  ];

  var TOXIC = [
    'stupid', 'idiot', 'dumb', 'useless', 'liar', 'lying', 'shut up', 'pathetic', 'ridiculous',
    'unprofessional', 'selfish', 'lazy', 'crazy', 'hate', 'loser', 'incompetent', 'disgusting',
    'shame', 'jerk', 'nonsense', 'moron', 'insane'
  ];

  var INTENSIFIERS = [
    'very', 'really', 'so', 'extremely', 'absolutely', 'totally', 'completely', 'utterly',
    'insanely', 'super', 'incredibly', 'horribly', 'constantly'
  ];

  var GENERALIZATION_RE = [
    { re: /\b(you|she|he|they|it)\s+(never|always)\b/i, label: 'Generalization' },
    { re: /\b(every time|every single time|all the time|every damn time)\b/i, label: 'Generalization' },
    { re: /\b(nobody|everyone|everybody|no one)\s+(ever|always|never)\b/i, label: 'Generalization' },
    { re: /\b(everything|nothing|everyone|everybody)\b.{0,14}\b(always|never)\b/i, label: 'Generalization' },
    { re: /\bthe (same|usual|typical) (thing|story|excuse)\b/i, label: 'Generalization' }
  ];

  var ABSOLUTE_RE = [
    { re: /\balways\b|\bnever\b/i, label: 'Absolute language' }
  ];

  var BLAME_RE = [
    { re: /\b(always|never|everything)\b.{0,12}\bmy fault\b/i, label: 'Blame attribution' },
    { re: /\byou('re| are) (the )?(problem|reason|cause)\b/i, label: 'Personal blame' },
    { re: /\bit('s| is) (all )?your fault\b/i, label: 'Personal blame' },
    { re: /\byou('re| are) (so |too )?(selfish|lazy|stupid|useless|incompetent|wrong)\b/i, label: 'Personal attack' },
    { re: /\byou (always|never) (blame|accuse|criticize)\b/i, label: 'Blame attribution' }
  ];

  var DEFENSIVE_RE = [
    { re: /\b(that's|that is) not (fair|true|my fault|accurate)\b/i, label: 'Defensiveness' },
    { re: /\bnot (my|our) fault\b/i, label: 'Defensiveness' },
    { re: /\byou always blame me\b/i, label: 'Defensiveness' },
    { re: /\byou don't understand\b/i, label: 'Defensiveness' }
  ];

  var CONCESSION_RE = [
    { re: /\b(okay|ok|fine|alright|alright|fair enough|you're right|you are right)\b/i, label: 'Concession' },
    { re: /\b(agree|agreed|let's|lets|let us|shall we)\b/i, label: 'Agreement' },
    { re: /\bwilling to\b/i, label: 'Willingness to adjust' },
    { re: /\b(step back|move on|take a break|start fresh|both need to|we both)\b/i, label: 'De-escalation attempt' },
    { re: /\b(together|compromise|meet halfway|work it out)\b/i, label: 'Compromise attempt' }
  ];

  var REQUEST_RE = [
    { re: /\b(can you|could you|would you|please|how about|maybe we|maybe we should|let's|lets)\b/i, label: 'Request / proposal' }
  ];

  var APOLOGY_RE = [
    { re: /\b(sorry|apologize|apologies|my bad|my mistake)\b/i, label: 'Apology' }
  ];

  var TOPICS = [
    { name: 'Deadlines & deliverables', re: /\b(deadline|deadlines|deliver|deliverables|report|task|tasks|schedule|meeting|on time|late|requirements)\b/i },
    { name: 'Responsibility & blame', re: /\b(responsib|fault|blame|accountab|who (did|was)|your job|my job|priorit|expectations|unclear)\b/i },
    { name: 'Communication', re: /\b(listen|heard|unheard|ignore|interrupt|communicat|talk|explain|explanation|message|clarif|point|get to)\b/i },
    { name: 'Respect & fairness', re: /\b(respect|appreciate|fair|unfair|value|trust)\b/i },
    { name: 'Money & budget', re: /\b(money|budget|bill|cost|pay|expensive|salary)\b/i },
    { name: 'Family & home', re: /\b(family|kids|children|home|house|dinner|weekend|partner)\b/i },
    { name: 'Health & wellbeing', re: /\b(health|tired|exhausted|stress|stressful|sick|sleep|burnt)\b/i }
  ];

  return {
    POSITIVE: POSITIVE, NEGATIVE: NEGATIVE, TOXIC: TOXIC, INTENSIFIERS: INTENSIFIERS,
    GENERALIZATION_RE: GENERALIZATION_RE, ABSOLUTE_RE: ABSOLUTE_RE, BLAME_RE: BLAME_RE,
    DEFENSIVE_RE: DEFENSIVE_RE, CONCESSION_RE: CONCESSION_RE, REQUEST_RE: REQUEST_RE,
    APOLOGY_RE: APOLOGY_RE, TOPICS: TOPICS
  };
}));
