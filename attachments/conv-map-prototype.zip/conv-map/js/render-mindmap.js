// render-mindmap.js — collapsible mind-map tree built as nested <details>/<summary>.
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else { root.ConvMap = root.ConvMap || {}; root.ConvMap.MindMap = factory(); }
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function snippet(t, n) {
    n = n || 56;
    t = t.replace(/\s+/g, ' ').trim();
    return t.length > n ? t.slice(0, n).replace(/\s+\S*$/, '') + '…' : t;
  }
  function chip(text, cls) {
    return '<span class="chip ' + cls + '">' + esc(text) + '</span>';
  }

  function leaf(u) {
    var c = [];
    c.push('<li class="mm-leaf">');
    c.push(chip(u.speaker, 'sp'));
    c.push(chip(u.sentiment, 'senti-' + u.sentiment));
    c.push(chip(u.tone, 'tone'));
    c.push('<span class="mm-text">' + esc(snippet(u.text)) + '</span>');
    c.push(chip(u.timestamp, 'ts'));
    if (u.emotional_intensity > 0.45) c.push(chip('🔥 ' + u.emotional_intensity, 'heat'));
    c.push(chip(u.conflict_level, 'lv-' + u.conflict_level));
    if (u.possible_trigger) c.push('<span class="mm-badge trig" title="' + esc(u.possible_trigger.reason) + '">⚡ trigger</span>');
    if (u.deescalating) c.push('<span class="mm-badge calm">✓ de-escalation</span>');
    if (u.toxic_words.length) c.push('<span class="mm-badge tox">⚠ toxic: ' + esc(u.toxic_words.join(', ')) + '</span>');
    c.push('</li>');
    return c.join('');
  }

  function grp(title, items, badgeText, cls) {
    var c = [];
    c.push('<li class="mm-group"><details' + (cls === 'open' ? ' open' : '') + '><summary class="mm-summary">');
    c.push('<span class="mm-caret"></span>' + esc(title));
    if (badgeText) c.push(chip(badgeText, 'count'));
    c.push('<span class="mm-summary-line">' + esc(items.length + ' turn' + (items.length === 1 ? '' : 's')) + '</span>');
    c.push('</summary><ul class="mm-leaf-list">');
    items.forEach(function (u) { c.push(leaf(u)); });
    c.push('</ul></details></li>');
    return c.join('');
  }

  function buildHtml(data) {
    var c = [];
    c.push('<div class="mm-root"><details open><summary class="mm-root-summary">💬 Conversation</summary><ul class="mm-list">');
    c.push('<li class="mm-branch-label">🗂 Topics</li>');
    data.topics.forEach(function (t) {
      var avg = t.children.reduce(function (a, u) { return a + u.emotional_intensity; }, 0) / Math.max(1, t.children.length);
      c.push(grp(t.label, t.children, '', 'open'));
    });
    if (data.triggers.length) {
      c.push('<li class="mm-branch-label">⚡ Possible triggers</li>');
      c.push(grp('Trigger moments', data.triggers, data.triggers.length, ''));
    }
    if (data.resolutions.length) {
      c.push('<li class="mm-branch-label">🤝 Resolution attempts</li>');
      c.push(grp('Concessions / calmer turns', data.resolutions, data.resolutions.length, ''));
    }
    c.push('</ul></details></div>');
    return c.join('');
  }

  function render(data, container) {
    if (container) container.innerHTML = buildHtml(data);
  }

  return { buildHtml: buildHtml, render: render };
}));
