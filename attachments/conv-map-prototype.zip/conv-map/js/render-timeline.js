// render-timeline.js — pure SVG builder for the escalation timeline.
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else { root.ConvMap = root.ConvMap || {}; root.ConvMap.Timeline = factory(); }
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  var SENT_COLOR = { positive: '#2e7d32', neutral: '#8a8f98', negative: '#c62828' };
  var LV_COLOR = { low: '#8a8f98', rising: '#f9a825', high: '#ef6c00', critical: '#c62828' };

  function speakersOrder(uris) {
    var arr = [], map = {};
    uris.forEach(function (u) { if (!map[u.speaker]) { map[u.speaker] = 1; arr.push(u.speaker); } });
    return arr;
  }

  function niceStep(tMax) {
    var raw = tMax / 8;
    var steps = [1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600];
    for (var i = 0; i < steps.length; i++) if (steps[i] >= raw) return steps[i];
    return 3600;
  }

  /* Pure builder: returns SVG markup string. width in px (falls back to 880). */
  function buildSvg(uris, width) {
    var W = width || 880; if (W < 340) W = 340;
    var padL = 108, padR = 22, padT = 26;
    var speakers = speakersOrder(uris);
    var laneH = 46, laneGap = 8;
    var bandH = 64; // top conflict band
    var laneY0 = padT + bandH + 18;
    var legendH = 34;
    var H = laneY0 + speakers.length * (laneH + laneGap) + legendH + 12;

    var tMax = 1;
    uris.forEach(function (u) { if (u.time > tMax) tMax = u.time; });
    var tRange = tMax + 4;
    var bodyW = W - padL - padR;
    function x(t) { return padL + (t / tRange) * bodyW; }

    var s = [];
    s.push('<svg xmlns="http://www.w3.org/2000/svg" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" class="timeline" font-family="system-ui, sans-serif">');

    // conflict band
    s.push('<rect x="' + padL + '" y="' + padT + '" width="' + bodyW + '" height="' + bandH + '" fill="#f4f5fa" rx="6"/>');
    s.push('<text x="' + (padL - 10) + '" y="' + (padT + 14) + '" text-anchor="end" font-size="11" fill="#565b66">Conflict</text>');
    s.push('<text x="' + (padL - 10) + '" y="' + (padT + 28) + '" text-anchor="end" font-size="11" fill="#565b66">level</text>');

    // lane bands
    speakers.forEach(function (sp, i) {
      var y = laneY0 + i * (laneH + laneGap);
      s.push('<rect x="' + padL + '" y="' + y + '" width="' + bodyW + '" height="' + laneH + '" fill="' + (i % 2 ? '#fbfbfd' : '#f1f2f7') + '" rx="6"/>');
      s.push('<text x="' + (padL - 10) + '" y="' + (y + laneH / 2 + 4) + '" text-anchor="end" font-size="12" font-weight="600" fill="#33363d">' + esc(sp) + '</text>');
    });

    // time grid + labels
    var step = niceStep(tRange);
    var tickY = laneY0 + speakers.length * (laneH + laneGap) + 6;
    for (var t = 0; t <= tRange; t += step) {
      s.push('<line x1="' + x(t) + '" y1="' + padT + '" x2="' + x(t) + '" y2="' + (tickY - 8) + '" stroke="#dfe1e8" stroke-width="1"/>');
      s.push('<text x="' + x(t) + '" y="' + (tickY + 12) + '" text-anchor="middle" font-size="10" fill="#8a8f98">' + esc(ConvMapTimelineFmt(t)) + '</text>');
    }

    // conflict curve
    var pts = uris.map(function (u) {
      var y = padT + bandH - 6 - u.conflict_after * (bandH - 22);
      return x(u.time).toFixed(1) + ',' + y.toFixed(1);
    });
    s.push('<polyline points="' + pts.join(' ') + '" fill="none" stroke="#4f46e5" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" opacity="0.85"/>');
    // faint area under curve
    if (pts.length) {
      var area = 'M' + x(uris[0].time).toFixed(1) + ',' + (padT + bandH - 6) + ' L' + pts.join(' L') +
        ' L' + x(uris[uris.length - 1].time).toFixed(1) + ',' + (padT + bandH - 6) + ' Z';
      s.push('<path d="' + area + '" fill="#4f46e5" opacity="0.08"/>');
    }

    // utterances
    uris.forEach(function (u, i) {
      var lane = speakers.indexOf(u.speaker);
      if (lane < 0) lane = 0;
      var cy = laneY0 + lane * (laneH + laneGap) + laneH / 2;
      var cx = x(u.time);
      var r = 4 + u.emotional_intensity * 9;
      var fill = SENT_COLOR[u.sentiment] || '#8a8f98';
      var tip = u.timestamp + ' · ' + u.speaker + ' · ' + u.sentiment + ' · intensity ' + u.emotional_intensity +
        (u.topic ? ' · ' + u.topic : '') + (u.communication_pattern ? ' · pattern: ' + u.communication_pattern : '') + (u.toxic_words.length ? ' · toxic: ' + u.toxic_words.join(', ') : '') + '\n' + u.text;
      s.push('<g><circle cx="' + cx.toFixed(1) + '" cy="' + cy.toFixed(1) + '" r="' + r.toFixed(1) + '" fill="' + fill + '" fill-opacity="0.85" stroke="#33363d" stroke-width="1"><title>' + esc(tip) + '</title></circle>');

      if (u.possible_trigger) {
        var dx = cx, dy = cy - 18;
        s.push('<path d="M' + dx.toFixed(1) + ',' + (dy - 6) + ' L' + (dx + 5).toFixed(1) + ',' + dy + ' L' + dx.toFixed(1) + ',' + (dy + 6) + ' L' + (dx - 5).toFixed(1) + ',' + dy + ' Z" fill="#d32f2f"><title>Possible trigger: ' + esc(u.possible_trigger.reason + ' · ' + (u.possible_trigger.topic || '')) + '</title></path>');
      }
      if (u.deescalating) {
        s.push('<circle cx="' + cx.toFixed(1) + '" cy="' + (cy + 17) + '" r="5.5" fill="none" stroke="#2e7d32" stroke-width="2" stroke-dasharray="3 2"><title>De-escalation attempt: ' + esc(u.communication_pattern || 'calming turn') + '</title></circle>');
      }
      s.push('</g>');
    });

    // legend
    var ly = H - 20;
    function legendItem(list, x0, label) {
      s.push(list);
      s.push('<text x="' + (x0 + 10) + '" y="' + (ly + 4) + '" font-size="11" fill="#565b66">' + esc(label) + '</text>');
    }
    var lx = padL;
    legendItem('<circle cx="' + (lx + 5) + '" cy="' + ly + '" r="5" fill="#c62828"/>', lx, 'negative');
    lx += 78;
    legendItem('<circle cx="' + (lx + 5) + '" cy="' + ly + '" r="5" fill="#8a8f98"/>', lx, 'neutral');
    lx += 72;
    legendItem('<circle cx="' + (lx + 5) + '" cy="' + ly + '" r="5" fill="#2e7d32"/>', lx, 'positive');
    lx += 78;
    legendItem('<path d="M' + (lx + 2) + ',' + (ly - 5) + ' L' + (lx + 9) + ',' + ly + ' L' + (lx + 2) + ',' + (ly + 5) + ' Z" fill="#d32f2f"/>', lx, 'trigger');
    lx += 72;
    legendItem('<circle cx="' + (lx + 5) + '" cy="' + ly + '" r="5" fill="none" stroke="#2e7d32" stroke-width="2" stroke-dasharray="3 2"/>', lx, 'de-escalation');
    lx += 120;
    legendItem('<line x1="' + lx + '" y1="' + ly + '" x2="' + (lx + 22) + '" y2="' + ly + '" stroke="#4f46e5" stroke-width="2.5"/>', lx + 22, 'conflict level curve');

    s.push('</svg>');
    return s.join('');
  }

  function ConvMapTimelineFmt(sec) {
    sec = Math.max(0, Math.round(sec));
    var m = Math.floor(sec / 60), s = sec % 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }

  function render(uris, container) {
    if (!container) return '';
    var w = container.clientWidth || 880;
    container.innerHTML = buildSvg(uris, w);
  }

  return { buildSvg: buildSvg, render: render };
}));
