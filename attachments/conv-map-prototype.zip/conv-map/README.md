# Conversation Map — prototype v0.1

A zero-dependency, offline-first tool that turns a conversation transcript into a structured analysis:
tone, sentiment, emotional intensity, possible triggers, conflict escalation, a timeline map, a mind map,
and hedged communication suggestions.

**One-line product definition (v0.1):** *Upload a conversation, analyze its emotional and conflict
patterns, and display the results on a simple timeline.*

## Run it
Just open `index.html` in a browser. Nothing to install, nothing to upload, no server.

```
conv-map/
├── index.html              ← open this
├── js/
│   ├── lexicon.js          ← word lists + pattern rules (fully replaceable)
│   ├── engine.js           ← parse → segment → speaker split → analyze → score → summary
│   ├── render-timeline.js  ← SVG escalation timeline (pure builder)
│   └── render-mindmap.js   ← collapsible HTML mind-map tree
├── data/sample.js          ← preloaded sample conversation
└── test/run.js             ← headless pipeline test: node test/run.js
```

## Pipeline (each stage isolated so a method can be swapped)
1. **parse** — accepts dialog lines `[00:04:12] Name: text` or `Name: text`, or JSON
   (`{segments:[{speaker, start, text}]}`) — auto speaker-split for unlabeled lines.
2. **analyze** — per turn: sentiment (lexicon + negation handling), emotional intensity 0–1,
   topic, pattern detection (generalization, absolutes, personal blame, personal attack,
   defensiveness, concession, apology, requests), toxic wording, trigger inference.
3. **conflict model** — a running 0–1 conflict level per turn; escalations and de-escalations recorded.
4. **summary** — hedged phrasing (“possible trigger”, “may indicate”, “this interpretation is uncertain”)
   and per-pattern rephrasing suggestions.
5. **render** — SVG timeline (speaker lanes + conflict curve + trigger/calm markers) and a mind map.

## Per-turn record (schema as specified)
```json
{
  "timestamp": "00:04:12",
  "speaker": "Speaker A",
  "text": "You never listen to me",
  "topic": "Being heard",
  "tone": "frustrated",
  "sentiment": "negative",
  "emotional_intensity": 0.8,
  "possible_trigger": "Perceived lack of attention",
  "communication_pattern": "Generalization",
  "conflict_level": "rising"
}
```
(engine.js also stores machine fields used by the renderers: time, negative_words, patterns,
conflict_after, deescalating, …)

## v0.1 scope decisions
- **Input:** transcript first. Audio upload is a stub (`transcribe()` in index.html) wired to a
  pluggable interface for Whisper / Deepgram / Web Speech API later.
- **Time:** post-conversation analysis, not real time.
- **Context:** workplace + personal (location-agnostic; contexts pluggable later).
- **Five core categories:** speaker · tone/sentiment · emotional intensity · trigger · conflict level.
  (Topic and pattern labels are shown but treated as secondary.)
- **Output style:** supportive explanations preferred over raw “toxic” flags; labels are probabilistic.

## Honest limitations
- Rule-based, not ML: patterns are keyword/regex driven, so sarcasm and subtle cues are often missed.
- Speaker labels on unlabeled lines alternate by heuristic — verify them for noisy transcripts.
- Emotion/intent cannot be determined perfectly from speech alone: every label is an estimate.

## Roadmap
Later: audio transcription plug-in, long-term tracking across conversations, personalized coaching,
custom emotional categories, real-time analysis, interactive mind maps, conversation comparison,
user-defined relationship/workplace contexts.
