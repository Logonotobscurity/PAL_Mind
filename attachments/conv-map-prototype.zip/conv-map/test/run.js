// test/run.js — headless verification of the pipeline (no DOM needed).
// Run: node test/run.js
'use strict';
var Lexicon = require('../js/lexicon.js');
var Engine = require('../js/engine.js');
var Timeline = require('../js/render-timeline.js');
var MindMap = require('../js/render-mindmap.js');
var SAMPLE = require('../data/sample.js');

var parsed = Engine.parseTranscript(SAMPLE.text);
var analysis = Engine.analyzeAll(parsed.utterances);
var summary = Engine.buildSummary(analysis.utterances);
var mm = Engine.buildMindMapData(analysis.utterances);
var svg = Timeline.buildSvg(analysis.utterances, 900);
var mmHtml = MindMap.buildHtml(mm);

var results = [];
function check(name, ok, extra) { results.push({ name: name, ok: !!ok, extra: extra }); }

check('parse format = dialog', parsed.format === 'dialog', parsed.format);
check('>= 10 utterances', parsed.utterances.length >= 10, parsed.utterances.length);
check('>= 2 speakers (Speaker A/B split)', analysis.speakers.length >= 2, analysis.speakers.join(', '));
check('some negative sentiment', analysis.utterances.some(function (u) { return u.sentiment === 'negative'; }));
check('some positive sentiment (recovery arc)', analysis.utterances.some(function (u) { return u.sentiment === 'positive'; }));
check('at least one possible trigger', analysis.utterances.some(function (u) { return u.possible_trigger; }));
check('conflict reaches high/critical', analysis.utterances.some(function (u) { return u.conflict_level === 'high' || u.conflict_level === 'critical'; }));
check('escalations recorded', analysis.escalations.length > 0, analysis.escalations.length);
check('de-escalations recorded', analysis.deescalations.length > 0, analysis.deescalations.length);
check('summary lines non-empty', summary.summaryLines.length > 0, summary.summaryLines.length);
check('rephrasings non-empty', summary.rephrasings.length > 0, summary.rephrasings.length);
check('mind map has topics', mm.topics.length > 0, mm.topics.length);
check('mind map has triggers branch', mm.triggers.length > 0, mm.triggers.length);
check('timeline SVG non-empty', typeof svg === 'string' && svg.indexOf('<svg') === 0 && svg.indexOf('polyline') > 0, svg.length + ' chars');
check('mind map HTML has <details>', mmHtml.indexOf('<details') >= 0);

var failed = results.filter(function (r) { return !r.ok; });
console.log('=== Conversation Map — headless test ===');
results.forEach(function (r) { console.log((r.ok ? '  ✓ ' : '  ✗ ') + r.name + (r.extra ? '  [' + r.extra + ']' : '')); });
console.log('--- parsed sample (' + parsed.utterances.length + ' turns, format=' + parsed.format + ') ---');
analysis.utterances.forEach(function (u, i) {
  console.log(String(i).padStart(2) + ' ' + u.timestamp + ' ' + u.speaker.padEnd(5) + ' ' + u.sentiment.padEnd(8) + ' tone=' + u.tone.padEnd(12) + ' int=' + u.emotional_intensity + ' lvl=' + u.conflict_level.padEnd(8) + ' ' + (u.communication_pattern || '—') + (u.possible_trigger ? ' ⚡' : ''));
});
console.log('--- summary ---');
summary.summaryLines.forEach(function (l) { console.log('  • ' + l); });
console.log('--- rephrasings (' + summary.rephrasings.length + ') ---');
summary.rephrasings.forEach(function (r) { console.log('  • ' + r.pattern + ': ' + r.suggestion); });
console.log('--- mind map (' + mm.topics.length + ' topics, ' + mm.triggers.length + ' triggers, ' + mm.resolutions.length + ' resolution turns) ---');
console.log(failed.length === 0 ? '\nALL CHECKS PASSED' : '\n' + failed.length + ' CHECK(S) FAILED');
process.exit(failed.length === 0 ? 0 : 1);
